#ifndef BMP__H
#define BMP__H
#include "lcd.h"
extern BMP logo1;
extern BMP logo;
extern BMP over;
#endif


