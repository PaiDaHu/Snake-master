#ifndef BEEP__H
#define BEEP__H
#include "sys.h"
#define BEEP PFout(8)
void BEEP_Init(void);
#endif
